<?php

    //Inclui o arquivo de conexão com o DB
    include "database.php";

    //Recupera as informações do formulário via POST
    $nome_aluno = $_POST['nome_aluno'];
    $email_aluno = $_POST['email_aluno'];
    $celular_aluno = $_POST['celular_aluno'];

    //Criando a string em SQL
    $sql = "INSERT INTO pj_aluno (pj_aluno_nome, pj_aluno_email, pj_aluno_cel) VALUES ('$nome_aluno', '$email_aluno', '$celular_aluno')";

    //Realizar uma verificação e enviar as informação aos banco de dados
    if(mysqli_query($conexao, $sql)){
        header("Location: lista_cadastro.php");
    }else{
        echo "Falha ao cadastrar!";
    }

?>