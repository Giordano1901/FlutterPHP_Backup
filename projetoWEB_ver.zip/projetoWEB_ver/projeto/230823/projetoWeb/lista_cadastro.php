        <?php
            include "database.php";
            
            include "header.php";

            $sql_lista = "SELECT * FROM pj_aluno";

            $dados_tabela_db = mysqli_query($conexao, $sql_lista);
        ?>

        <br>
            <h1>Lista de Alunos</h1>
        </br>

        <table class="table table-striped">
            <thead class="table-dark">
                <tr>
                    <th>Nome:</th>
                    <th>E-mail:</th>
                    <th>Celular:</th>
                </tr>
            </thead>
            <tbody>
                <?php while($dados = mysqli_fetch_array($dados_tabela_db)) {?>
                    <tr>
                        <td><?php echo $dados['pj_aluno_nome']; ?></td>
                        <td><?php echo $dados['pj_aluno_email']; ?></td>
                        <td><?php echo $dados['pj_aluno_cel']; ?></td>
                    </tr>
                <?php }?>
            </tbody>
        </table>
        

        <?php
            include "footer.php";
        ?>