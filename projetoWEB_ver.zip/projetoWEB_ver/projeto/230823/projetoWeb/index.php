        <!-- <form action="cadastro.php" method="post">
            <label for="nome_aluno">Nome: </label>
            <input type="text" name="nome_aluno" id="nome_aluno" required>
            <label for="email_aluno">E-mail: </label>
            <input type="email" name="email_aluno" id="email_aluno" required>
            <label for="senha_aluno">Senha: </label>
            <input type="password" name="senha_aluno" id="senha_aluno" required>
            <input type="submit" value="Cadastrar aluno">
        </form> -->

        <?php
            include "header.php";
        ?>

        <h1>Projeto PHP - Flutter - React - PHP</h1>

        <?php
            include "footer.php";
        ?>