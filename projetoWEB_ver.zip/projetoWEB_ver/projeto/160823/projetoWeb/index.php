        <!-- <form action="cadastro.php" method="post">
            <label for="nome_aluno">Nome: </label>
            <input type="text" name="nome_aluno" id="nome_aluno" required>
            <label for="email_aluno">E-mail: </label>
            <input type="email" name="email_aluno" id="email_aluno" required>
            <label for="senha_aluno">Senha: </label>
            <input type="password" name="senha_aluno" id="senha_aluno" required>
            <input type="submit" value="Cadastrar aluno">
        </form> -->

        <?php
            include "header.php";
        ?>

        <h1>Projeto PHP - CRUD - Flutter</h1>
        <!-- <p>Desenvolvimento de aplicativos com Flutter - PHP</p> -->
        <p>Selecione a opção desejada: </p>
        <a href="form_cadastro.php">
            <img src="img/icones/cadastro.png" alt="Cadastro de aluno">Cadastro de Alunos
        </a>
        <a href="lista_cadastro.php">
            <img src="img/icones/lista.png" alt="lista de cadastro">Lista de cadastro
        </a>

        <?php
            include "footer.php";
        ?>