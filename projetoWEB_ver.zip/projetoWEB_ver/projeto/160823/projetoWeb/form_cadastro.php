        <?php
            include "header.php";
        ?>

        <h1>Projeto PHP - CRUD - Flutter</h1>
        <!-- <p>Desenvolvimento de aplicativos com Flutter - PHP</p> -->
        <p>Cadastro de Alunos</p>
        
        <form action="cadastro.php" method="post">
            <label for="nome_aluno">Nome: </label>
            <input type="text" name="nome_aluno" id="nome_aluno" required>

            <label for="email_aluno">E-mail: </label>
            <input type="email" name="email_aluno" id="email_aluno" required>

            <label for="celular_aluno">Celular: </label>
            <input type="text" name="celular_aluno" id="celular_aluno" required>

            <input type="submit" value="Cadastrar Aluno">
        </form>

        <?php
            include "footer.php";
        ?>